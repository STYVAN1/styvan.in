import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ShoppingCart, Shirt } from "lucide-react";

const products = [
  {
    id: 1,
    name: "Men’s Formal Shirt – Snowflake Print",
    image: "/shirt1.jpg",
    price: "₹899",
    sizes: ["38", "40", "42"],
    brand: "Styvan",
    fabric: "Cotton",
    fit: "Regular",
    sleeve: "Full Sleeve",
  },
];

export default function ShirtStore() {
  return (
    <div className="p-6 max-w-6xl mx-auto">
      <header className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <Shirt className="w-8 h-8" /> Styvan Shirts
        </h1>
        <Button variant="outline">
          <ShoppingCart className="mr-2 w-4 h-4" /> Cart
        </Button>
      </header>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {products.map((product) => (
          <Card key={product.id} className="rounded-2xl shadow-md">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-64 object-cover rounded-t-2xl"
            />
            <CardContent className="p-4">
              <h2 className="text-xl font-semibold mb-2">{product.name}</h2>
              <p className="text-sm text-gray-600 mb-1">Brand: {product.brand}</p>
              <p className="text-sm text-gray-600 mb-1">Fabric: {product.fabric}</p>
              <p className="text-sm text-gray-600 mb-1">Fit: {product.fit}</p>
              <p className="text-sm text-gray-600 mb-1">Sleeve: {product.sleeve}</p>
              <p className="text-lg font-bold mb-2">{product.price}</p>
              <div className="flex items-center gap-2 mb-4">
                <label htmlFor="size" className="text-sm">Size:</label>
                <select className="border px-2 py-1 rounded">
                  {product.sizes.map((size) => (
                    <option key={size}>{size}</option>
                  ))}
                </select>
              </div>
              <Button className="w-full">Add to Cart</Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}